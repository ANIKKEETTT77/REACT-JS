// import logo from './logo.svg';
import './App.css';
import { Paragraph } from './components/Paragraph';

function App() {
  return (
    <div>
      <h2 style={{color:"red"}}>React-Task-1</h2>
      <Paragraph />
    </div>
  );
}

export default App;
