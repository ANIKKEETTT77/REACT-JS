// import logo from './logo.svg';
import './App.css';
import { Calculator } from './components/Calculator';

function App() {
  return (
    <div>
      <h2 style={{color:"red"}}>React-task-5</h2>
      <Calculator />
    </div>
  );
}

export default App;
