import './App.css';
// import Button from 'react-bootstrap/Button';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container } from './components/Container';

function App() {
  return (
    <Container/>
  );
}

export default App;
